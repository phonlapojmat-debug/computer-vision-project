# rotten-fruit > 2026-07-23 3:16pm
https://universe.roboflow.com/phonlapoj-matpongthavorn/rotten-fruit-pfbpt-gutpy

Provided by a Roboflow user
License: CC BY 4.0

